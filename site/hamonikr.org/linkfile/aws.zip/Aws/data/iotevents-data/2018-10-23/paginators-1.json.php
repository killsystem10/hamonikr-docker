<?php
// This file was auto-generated from sdk-root/src/data/iotevents-data/2018-10-23/paginators-1.json
return [ 'pagination' => [],];
